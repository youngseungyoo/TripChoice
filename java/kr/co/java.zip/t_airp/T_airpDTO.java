package kr.co.tripChoice.t_airp;

public class T_airpDTO {

	private String ta_code;
	private String ta_dep;
	private String ta_arr;
	private int ta_pax;
	private String ta_flightnum;
	private String ta_sdate;
	private String ta_fdate;
	private String trip_code;

	public T_airpDTO() {
	}

	public String getTa_code() {
		return ta_code;
	}

	public void setTa_code(String ta_code) {
		this.ta_code = ta_code;
	}

	public String getTa_dep() {
		return ta_dep;
	}

	public void setTa_dep(String ta_dep) {
		this.ta_dep = ta_dep;
	}

	public String getTa_arr() {
		return ta_arr;
	}

	public void setTa_arr(String ta_arr) {
		this.ta_arr = ta_arr;
	}

	public int getTa_pax() {
		return ta_pax;
	}

	public void setTa_pax(int ta_pax) {
		this.ta_pax = ta_pax;
	}

	public String getTa_flightnum() {
		return ta_flightnum;
	}

	public void setTa_flightnum(String ta_flightnum) {
		this.ta_flightnum = ta_flightnum;
	}

	public String getTa_sdate() {
		return ta_sdate;
	}

	public void setTa_sdate(String ta_sdate) {
		this.ta_sdate = ta_sdate;
	}

	public String getTa_fdate() {
		return ta_fdate;
	}

	public void setTa_fdate(String ta_fdate) {
		this.ta_fdate = ta_fdate;
	}

	public String getTrip_code() {
		return trip_code;
	}

	public void setTrip_code(String trip_code) {
		this.trip_code = trip_code;
	}

}// class end
