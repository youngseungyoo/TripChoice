package kr.co.tripChoice.airp_reser;

public class Airp_reserDTO {

	private String tar_code;
	private String ta_code;
	private String tar_seat;
	private String tu_id;
	private String tar_name;
	private String tar_passcode;
	
	private String[] tar_code_list;
	private String[] ta_code_list;
	private String[] tar_seat_list;
	private String[] tu_id_list;
	private String[] tar_name_list;
	private String[] tar_passcode_list;
	
	public String[] getTar_code_list() {
		return tar_code_list;
	}
	public void setTar_code_list(String[] tar_code_list) {
		this.tar_code_list = tar_code_list;
	}
	public String[] getTa_code_list() {
		return ta_code_list;
	}
	public void setTa_code_list(String[] ta_code_list) {
		this.ta_code_list = ta_code_list;
	}
	public String[] getTar_seat_list() {
		return tar_seat_list;
	}
	public void setTar_seat_list(String[] tar_seat_list) {
		this.tar_seat_list = tar_seat_list;
	}
	public String[] getTu_id_list() {
		return tu_id_list;
	}
	public void setTu_id_list(String[] tu_id_list) {
		this.tu_id_list = tu_id_list;
	}
	public String[] getTar_name_list() {
		return tar_name_list;
	}
	public void setTar_name_list(String[] tar_name_list) {
		this.tar_name_list = tar_name_list;
	}
	public String[] getTar_passcode_list() {
		return tar_passcode_list;
	}
	public void setTar_passcode_list(String[] tar_passcode_list) {
		this.tar_passcode_list = tar_passcode_list;
	}
	public String getTar_code() {
		return tar_code;
	}
	public void setTar_code(String tar_code) {
		this.tar_code = tar_code;
	}
	public String getTa_code() {
		return ta_code;
	}
	public void setTa_code(String ta_code) {
		this.ta_code = ta_code;
	}
	public String getTar_seat() {
		return tar_seat;
	}
	public void setTar_seat(String tar_seat) {
		this.tar_seat = tar_seat;
	}
	public String getTu_id() {
		return tu_id;
	}
	public void setTu_id(String tu_id) {
		this.tu_id = tu_id;
	}
	public String getTar_name() {
		return tar_name;
	}
	public void setTar_name(String tar_name) {
		this.tar_name = tar_name;
	}
	public String getTar_passcode() {
		return tar_passcode;
	}
	public void setTar_passcode(String tar_passcode) {
		this.tar_passcode = tar_passcode;
	}


}// class end
